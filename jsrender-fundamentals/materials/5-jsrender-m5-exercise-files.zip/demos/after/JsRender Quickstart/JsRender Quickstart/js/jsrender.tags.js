﻿// registers custom tags
$.views.tags({
    createStars: function (rating) {
        var tag = this,
            ratingArray = [],
            defaultMax = 5,
            max = tag.props.max ? tag.props.max : defaultMax;
        for (var i = 1; i <= max; i++) {
            ratingArray.push(i <= rating ? 'rating fullStar' : 'rating emptyStar');
        }
        var htmlString = '';
        if (tag.tmpl) {
            // use the content, or the template passed in with tmpl property
            htmlString = tag.renderContent(ratingArray);
            //htmlString = $(tag.tmpl).render(ratingArray); //alternative
        } else {
            // compiles and registers it with a name
            if (!$.render.compiledRatingTmpl) {
                //console.log('creating compiledRatingTmpl: ' + rating);
                $.templates('compiledRatingTmpl', '<span class="{{:#data}}"></span>');
            }
    //            else {
    //                console.log('compiledRatingTmpl exists: ' + rating);
    //            }
            // use the compiled named template
            htmlString = $.render.compiledRatingTmpl(ratingArray);
        }
        return htmlString;
    },
    sort: function(array) {
        var ret = '',
            tag = this,
            sortFunction = tag.props.sortFunction;
        
        var sortedArray = array.sort(sortFunction);

        if (tag.props.reverse) {
            for (var i = sortedArray.length - 1; i >= 0; i--) {
                ret += tag.renderContent(sortedArray[i]);
                //ret += tag.tmpl.render(sortedArray[i]);
            }
        }
        else {
            // Render in ascending order
            ret += tag.renderContent(sortedArray);
            //ret += tag.tmpl.render(sortedArray);
        }
        return ret;
    },
    get: function (value) {
        var tag = this;
        return value || tag.props.defaultValue;
    },
    yesNo: function (value) {
        var tag = this;
        return value ? tag.props.yes : tag.props.no;
    }
});
