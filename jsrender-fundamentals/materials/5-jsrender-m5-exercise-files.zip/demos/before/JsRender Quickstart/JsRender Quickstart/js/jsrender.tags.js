﻿// registers custom tags
$.views.tags({
    sort: function(array) {
        var ret = '',
            tag = this,
            sortFunction = tag.props.sortFunction;

        var sortedArray = array.sort(sortFunction);

        if (tag.props.reverse) {
            for (var i = sortedArray.length - 1; i >= 0; i--) {
                ret += tag.renderContent(sortedArray[i]);
            }
        }
        else {
            ret += tag.renderContent(sortedArray);
        }
        return ret;
    },
    yesNo: function(value) {
        var tag = this;
        return value ? tag.props.yes : tag.props.no;
    },
    createStars: function(rating) {
        var tag = this,
            ratingArray = [],
            defaultMax = 5,
            max = tag.props.max ? tag.props.max : defaultMax;
        for (var i = 1; i <= max; i++) {
            ratingArray.push(i <= rating ? 'rating fullStar' : 'rating emptyStar');
        }
        var htmlString = '';
        if (tag.tmpl) {
            // use the content, or the template passed in with tmpl property
            htmlString = tag.renderContent(ratingArray);
        } else {
            // compiles and registers it with a name
            if (!$.render.compiledRatingTmpl) {
                $.templates('compiledRatingTmpl', '<span class="{{:#data}}"></span>');
            }
            // use the compiled named template
            htmlString = $.render.compiledRatingTmpl(ratingArray);
        }
        return htmlString;
    }
});
