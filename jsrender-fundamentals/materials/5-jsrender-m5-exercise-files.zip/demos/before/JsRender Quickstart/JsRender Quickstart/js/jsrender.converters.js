﻿$.views.converters({
    ensureUrl: function (value) {
        return (value 
            ? '../images/' + value 
            : '../images/icon-noimage.png');
    },
    priceAlert: function (value) {
        return (value < 1000 
            ? 'Super Hot Value' 
            : 'Great Price');
    }
});
