﻿var my = my || {};
my.utils = (function() {
    var 
		getPath = function(name) {
		    return "../templates/_" + name + ".tmpl.html";
		},
		renderStructure = function(item) {
		    $.when(
				$.get(getPath('portlet.header')),
				$.get(getPath('portlet.nav')),
				$.get(getPath('portlet.code'))
			)
			.done(function(header, nav, code) {
			    $.templates({
			        tmplHeader: header[0],
			        tmplNav: nav[0],
			        tmplCode: code[0]
			    });
			    $('#header').html($.render.tmplHeader(item.data));
			    $('#nav').html($.render.tmplNav(item.data));
			    $('.codePortlet').html($.render.tmplCode(item.data));
			    prettyPrint();
			})
			.fail(function(result) {
			    console.log('A portlet template failed to load');
			});
		},
		renderExtTmpl = function(item) {
		    var file = getPath(item.name);
		    $.when($.get(file))
			.done(function(tmplData) {
			    $.templates({ tmpl: tmplData });
			    $(item.selector).html($.render.tmpl(item.data));
			});
		};
    return {
        getPath: getPath,
        renderExtTmpl: renderExtTmpl,
        renderStructure: renderStructure
    };
})();
